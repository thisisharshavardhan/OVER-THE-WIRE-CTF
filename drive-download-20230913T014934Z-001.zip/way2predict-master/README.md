# way2predict
AP CET’S COLLEGE AND BRANCH PREDICTION SYSTEM

Developed by 2020 Admitted Batch - D Section Students 

MYSQL Import File Name 
collegedb.sql

MySQL Default DataBase User Name : dcme

MYSQL Default Database Password : dcme030

MYSQL Database Name : collegedb

For Any Queries May Contact : dcme030@gmail.com 

Live Website http://way2predict.info/
